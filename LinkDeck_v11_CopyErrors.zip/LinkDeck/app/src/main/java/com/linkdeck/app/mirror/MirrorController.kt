package com.linkdeck.app.mirror

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.linkdeck.core.network.CmdReq
import com.linkdeck.core.network.ConnectionManager
import com.linkdeck.core.network.ConnectionState
import com.linkdeck.core.network.Envelope
import com.linkdeck.core.network.EventPush
import com.linkdeck.core.network.FramePush
import com.linkdeck.core.network.ProtoJson
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** CONTROLLER side of Normal-mode mirroring. */
@HiltViewModel
class MirrorViewModel @Inject constructor(
    private val connectionManager: ConnectionManager,
) : ViewModel() {

    /** Live connection state (connected / disconnected). */
    val connectionState: StateFlow<ConnectionState> = connectionManager.state

    private val _frame = MutableStateFlow<Bitmap?>(null)
    val frame: StateFlow<Bitmap?> = _frame

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active

    /** Live host status (battery / wifi / volume) shown in the side panel. */
    private val _status = MutableStateFlow<com.linkdeck.app.host.StatusInfo?>(null)
    val status: StateFlow<com.linkdeck.app.host.StatusInfo?> = _status

    /** Latest clipboard text received from the host. */
    private val _clip = MutableStateFlow("")
    val clip: StateFlow<String> = _clip

    init {
        viewModelScope.launch {
            connectionManager.state.collect { s ->
                if (s is ConnectionState.Connected) refreshStatus()
            }
        }
        viewModelScope.launch {
            connectionManager.events.collect { raw ->
                val env = runCatching { ProtoJson.decodeFromString(Envelope.serializer(), raw) }.getOrNull() ?: return@collect
                when (env.type) {
                    "frame" -> runCatching {
                        ProtoJson.decodeFromString(FramePush.serializer(), env.payload)
                    }.onSuccess { push ->
                        val bytes = Base64.decode(push.dataBase64, Base64.DEFAULT)
                        _frame.value = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                    "mirror_event" -> runCatching {
                        ProtoJson.decodeFromString(EventPush.serializer(), env.payload)
                    }.onSuccess { ev ->
                        when (ev.kind) {
                            "started" -> { _active.value = true; _message.value = null }
                            "stopped" -> { _active.value = false; _frame.value = null }
                            "flag_secure" -> _message.value = "flag_secure"
                            "normal_mode" -> _message.value = "normal_mode"
                            "error" -> _message.value = ev.dataJson
                        }
                    }
                    "clip" -> runCatching {
                        ProtoJson.decodeFromString(com.linkdeck.core.network.ClipPush.serializer(), env.payload)
                    }.onSuccess { c -> _clip.value = c.text }
                }
            }
        }
    }

    fun startMirror() = viewModelScope.launch {
        connectionManager.send(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("mirror_request")),
        )
    }

    fun stopMirror() = viewModelScope.launch {
        connectionManager.send(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("mirror_stop")),
        )
    }

    fun key(key: String) = viewModelScope.launch {
        connectionManager.send(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("inject_key", """{"key":"$key"}""")),
        )
    }

    fun tap(nx: Float, ny: Float) = viewModelScope.launch {
        connectionManager.send(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("inject_tap", """{"x":$nx,"y":$ny}""")),
        )
    }

    fun lock() = viewModelScope.launch {
        connectionManager.send(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("lock")),
        )
    }

    fun refreshStatus() = viewModelScope.launch {
        connectionManager.request(
            "cmd",
            ProtoJson.encodeToString(CmdReq.serializer(), CmdReq("get_status")),
        ).onSuccess { json ->
            runCatching {
                _status.value = ProtoJson.decodeFromString(
                    com.linkdeck.app.host.StatusInfo.serializer(), json,
                )
            }
        }
    }
}
