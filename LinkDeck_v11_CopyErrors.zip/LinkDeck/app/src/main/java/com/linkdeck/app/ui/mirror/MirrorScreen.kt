package com.linkdeck.app.ui.mirror

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.linkdeck.app.R
import com.linkdeck.core.design.LineIcon
import com.linkdeck.core.design.LineIconView
import com.linkdeck.core.design.Spacing
import com.linkdeck.core.network.ConnectionState
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

/**
 * CONTROLLER mirror screen. The mirrored phone renders as a REAL floating phone
 * window: device bezel, punch-hole camera, live status bar (clock + battery),
 * gesture pill, idle home wallpaper. Drag to move, pinch to resize, X to close.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MirrorScreen(onBack: () -> Unit) {
    val vm: MirrorViewModel = hiltViewModel()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.feature_mirror)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        LineIconView(icon = LineIcon.HOME, tint = MaterialTheme.colorScheme.onSurface, size = 24.dp)
                    }
                },
            )
        },
    ) { padding ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(padding)) {
            val wide = maxWidth >= 720.dp
            Row(Modifier.fillMaxSize()) {
                if (wide) {
                    MirrorSidePanel(vm, Modifier.width(250.dp).fillMaxHeight())
                }
                MirrorMainPane(
                    vm = vm,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
            }
        }
    }
}

@Composable
private fun MirrorMainPane(vm: MirrorViewModel, modifier: Modifier = Modifier) {
    val frame by vm.frame.collectAsState()
    val message by vm.message.collectAsState()
    val active by vm.active.collectAsState()
    val status by vm.status.collectAsState()

    var winOffset by remember { mutableStateOf(Offset.Zero) }
    var winScale by remember { mutableStateOf(1f) }

    Box(modifier.fillMaxSize()) {
        // ---- Floating REAL phone window ----
        Box(
            Modifier
                .align(Alignment.Center)
                .offset { IntOffset(winOffset.x.roundToInt(), winOffset.y.roundToInt()) }
                .graphicsLayer(scaleX = winScale, scaleY = winScale)
                .width(238.dp)
                .pointerInput(active) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        winOffset += pan
                        winScale = (winScale * zoom).coerceIn(0.45f, 2.2f)
                    }
                },
        ) {
            PhoneWindow(
                active = active,
                frame = frame,
                message = message,
                battery = status?.battery ?: -1,
                onClose = vm::stopMirror,
            )
        }

        // Bottom control bar
        Column(
            Modifier.align(Alignment.BottomCenter).padding(Spacing.xl),
            verticalArrangement = Arrangement.spacedBy(Spacing.sm),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                OutlinedButton(onClick = { vm.key("back") }) { Text(stringResource(R.string.key_back)) }
                OutlinedButton(onClick = { vm.key("home") }) { Text(stringResource(R.string.key_home)) }
                OutlinedButton(onClick = { vm.key("recents") }) { Text(stringResource(R.string.key_recents)) }
                OutlinedButton(onClick = vm::lock) { Text(stringResource(R.string.mirror_lock)) }
            }
            if (!active) {
                Button(onClick = vm::startMirror) { Text(stringResource(R.string.mirror_start)) }
            }
        }
    }
}

@Composable
private fun PhoneWindow(
    active: Boolean,
    frame: Bitmap?,
    message: String?,
    battery: Int,
    onClose: () -> Unit,
) {
    Box {
        // Device body (dark bezel)
        Column(
            Modifier
                .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(34.dp))
                .background(Color(0xFF15161A))
                .padding(horizontal = 7.dp, vertical = 9.dp),
        ) {
            // Screen
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(452.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.Black),
            ) {
                // Punch-hole camera
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 7.dp)
                        .size(11.dp)
                        .background(Color(0xFF050506), CircleShape)
                        .border(1.dp, Color(0xFF2A2B30), CircleShape),
                )

                // Content: frames, messages, or idle home
                when {
                    message == "flag_secure" -> ScreenMsg(stringResource(R.string.mirror_flag_secure))
                    message != null -> ScreenMsg(message)
                    frame != null -> Image(
                        bitmap = frame.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    else -> IdleHome()
                }

                // Status bar (below punch hole)
                PhoneStatusBar(active = active, battery = battery, modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp))

                // Gesture pill
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 6.dp)
                        .width(84.dp)
                        .height(4.dp)
                        .background(Color.White.copy(alpha = 0.65f), RoundedCornerShape(2.dp)),
                )
            }
        }

        // Close button on the bezel
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 2.dp, end = 2.dp)
                .size(28.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
        ) {
            LineIconView(icon = LineIcon.X, tint = MaterialTheme.colorScheme.onSurface, size = 13.dp)
        }
    }
}

@Composable
private fun PhoneStatusBar(active: Boolean, battery: Int, modifier: Modifier = Modifier) {
    var clock by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            delay(1000)
        }
    }
    Row(
        modifier.fillMaxWidth().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            if (active) {
                Box(Modifier.size(6.dp).background(Color(0xFFFF5252), CircleShape))
            }
            Text(clock, style = MaterialTheme.typography.labelSmall, color = Color.White)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            if (battery >= 0) {
                BatteryIcon(pct = battery)
                Text("$battery%", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
    }
}

@Composable
private fun BatteryIcon(pct: Int) {
    Box(
        Modifier
            .width(18.dp)
            .height(10.dp)
            .border(1.dp, Color.White, RoundedCornerShape(3.dp))
            .padding(1.5.dp),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(pct.coerceIn(0, 100) / 100f)
                .background(if (pct < 20) Color(0xFFFF5252) else Color.White, RoundedCornerShape(2.dp)),
        )
    }
    Box(
        Modifier
            .width(2.dp)
            .height(5.dp)
            .background(Color.White, RoundedCornerShape(1.dp)),
    )
}

/** Idle home screen shown when mirroring is not running. */
@Composable
private fun IdleHome() {
    val tiles = listOf(
        0xFFCECBF6, 0xFF9FE1CB, 0xFFF5C4B3, 0xFFFAC775,
        0xFFB5D4F4, 0xFFC0DD97, 0xFFF4C0D1, 0xFFD3D1C7,
        0xFF9FE1CB, 0xFFCECBF6, 0xFFFAC775, 0xFFB5D4F4,
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF2E4A78), Color(0xFF10141C))),
            ),
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            Spacer(Modifier.height(26.dp))
            Text(
                "12:30",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Text(
                "السبت ٢٤ أكتوبر",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(18.dp))
            tiles.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    row.forEach { c ->
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(13.dp))
                                .background(Color(c)),
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(Color.White.copy(alpha = 0.22f)),
            )
        }
    }
}

@Composable
private fun ScreenMsg(text: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF101216)), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.padding(16.dp),
        )
    }
}

@Composable
private fun MirrorSidePanel(vm: MirrorViewModel, modifier: Modifier = Modifier) {
    val status by vm.status.collectAsState()
    val clip by vm.clip.collectAsState()
    val conn by vm.connectionState.collectAsState()

    Column(
        modifier.padding(Spacing.xl).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(Spacing.md),
    ) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(Spacing.xl), verticalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LineIconView(icon = LineIcon.DEVICES, tint = MaterialTheme.colorScheme.onSurfaceVariant, size = 20.dp)
                    Spacer(Modifier.width(Spacing.sm))
                    Text(
                        stringResource(if (conn is ConnectionState.Connected) R.string.state_connected else R.string.state_disconnected),
                        style = MaterialTheme.typography.titleSmall,
                        color = if (conn is ConnectionState.Connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = vm::refreshStatus) {
                        Text(stringResource(R.string.mirror_refresh))
                    }
                }
                status?.let { s ->
                    Text(
                        stringResource(R.string.mirror_battery, s.battery),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        stringResource(R.string.mirror_wifi, s.wifiSsid),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        stringResource(R.string.mirror_volume, s.volume),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(Spacing.xl), verticalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                Text(stringResource(R.string.clipboard_title), style = MaterialTheme.typography.titleSmall)
                Text(
                    if (clip.isBlank()) stringResource(R.string.clipboard_empty) else clip.take(100),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
