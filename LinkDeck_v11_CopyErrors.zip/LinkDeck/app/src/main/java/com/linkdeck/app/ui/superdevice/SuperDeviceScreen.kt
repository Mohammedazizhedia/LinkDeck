package com.linkdeck.app.ui.superdevice

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.linkdeck.app.R
import com.linkdeck.app.devices.TrustedDeviceStore
import com.linkdeck.app.pairing.PairingManager
import com.linkdeck.core.design.LineIcon
import com.linkdeck.core.design.LineIconView
import com.linkdeck.core.design.Spacing
import com.linkdeck.core.network.ConnectionManager
import com.linkdeck.core.network.ConnectionState
import com.linkdeck.core.network.TrustedDevice
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

private class DragDevice(
    val key: String,
    val name: String,
    val trustedDevice: TrustedDevice?,
)

@HiltViewModel
class SuperDeviceViewModel @Inject constructor(
    val trustedStore: TrustedDeviceStore,
    val pairingManager: PairingManager,
    val connectionManager: ConnectionManager,
) : ViewModel()

/**
 * "Super Device"-style connection screen: drag a device chip into the centre
 * circle, confirm, and the secure connection is established. Devices come from
 * mDNS discovery + the trusted list. System-shade integration is OEM-only; this
 * delivers the same drag-to-connect flow inside the app.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuperDeviceScreen(onBack: () -> Unit) {
    val vm: SuperDeviceViewModel = hiltViewModel()
    val trusted by vm.trustedStore.devices.collectAsState()
    val discovered by vm.pairingManager.discovered.collectAsState()
    val state by vm.connectionManager.state.collectAsState()

    LaunchedEffect(Unit) { vm.pairingManager.startDiscovery() }
    DisposableEffect(Unit) { onDispose { vm.pairingManager.stopDiscovery() } }

    val devices = remember(trusted, discovered) {
        val list = mutableListOf<DragDevice>()
        trusted.forEach { d -> list.add(DragDevice("t:${d.id}", d.name, d)) }
        discovered
            .filter { disc -> trusted.none { it.ip == disc.host && it.port == disc.port } }
            .forEach { disc -> list.add(DragDevice("d:${disc.host}:${disc.port}", disc.name, null)) }
        list
    }

    var draggedKey by remember { mutableStateOf<String?>(null) }
    var hover by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<DragDevice?>(null) }
    var circleRect by remember { mutableStateOf(Rect.Zero) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.superdevice_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        LineIconView(icon = LineIcon.HOME, tint = MaterialTheme.colorScheme.onSurface, size = 24.dp)
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            val scale by animateFloatAsState(if (hover) 1.12f else 1f, label = "dropScale")
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .graphicsLayer(scaleX = scale, scaleY = scale)
                    .size(190.dp)
                    .onGloballyPositioned { circleRect = it.boundsInRoot() }
                    .background(
                        if (hover) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                        CircleShape,
                    )
                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LineIconView(
                        icon = LineIcon.DEVICES,
                        tint = if (hover) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        size = 44.dp,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Text(
                        text = when (state) {
                            is ConnectionState.Connected -> stringResource(R.string.state_connected)
                            ConnectionState.Connecting -> stringResource(R.string.state_connecting)
                            else -> stringResource(R.string.superdevice_drop_here)
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (hover) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Column(
                Modifier.align(Alignment.BottomCenter).padding(Spacing.xl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(Spacing.md),
            ) {
                devices.forEach { d ->
                    key(d.key) {
                        var chipOffset by remember { mutableStateOf(Offset.Zero) }
                        var chipRect by remember { mutableStateOf(Rect.Zero) }
                        val isDragging = draggedKey == d.key
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isDragging) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            tonalElevation = if (isDragging) 8.dp else 2.dp,
                            modifier = Modifier
                                .graphicsLayer {
                                    translationX = chipOffset.x
                                    translationY = chipOffset.y
                                }
                                .onGloballyPositioned { chipRect = it.boundsInRoot() }
                                .pointerInput(d.key) {
                                    detectDragGestures(
                                        onDragStart = { draggedKey = d.key },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            chipOffset += amount
                                            val center = Offset(
                                                chipRect.left + chipRect.width / 2f + chipOffset.x,
                                                chipRect.top + chipRect.height / 2f + chipOffset.y,
                                            )
                                            hover = circleRect.contains(center)
                                        },
                                        onDragEnd = {
                                            val center = Offset(
                                                chipRect.left + chipRect.width / 2f + chipOffset.x,
                                                chipRect.top + chipRect.height / 2f + chipOffset.y,
                                            )
                                            if (circleRect.contains(center)) confirm = d
                                            draggedKey = null
                                            hover = false
                                            chipOffset = Offset.Zero
                                        },
                                        onDragCancel = {
                                            draggedKey = null
                                            hover = false
                                            chipOffset = Offset.Zero
                                        },
                                    )
                                },
                        ) {
                            Row(
                                Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                LineIconView(
                                    icon = LineIcon.DEVICES,
                                    tint = if (isDragging) MaterialTheme.colorScheme.onPrimaryContainer
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                    size = 22.dp,
                                )
                                Spacer(Modifier.width(Spacing.sm))
                                Text(
                                    d.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isDragging) MaterialTheme.colorScheme.onPrimaryContainer
                                    else MaterialTheme.colorScheme.onSurface,
                                )
                                if (d.trustedDevice != null) {
                                    Spacer(Modifier.width(Spacing.xs))
                                    Text("✓", color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                if (devices.isEmpty()) {
                    Text(
                        stringResource(R.string.superdevice_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    confirm?.let { d ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(stringResource(R.string.superdevice_confirm_title, d.name)) },
            text = {
                Text(
                    if (d.trustedDevice != null) stringResource(R.string.superdevice_confirm_body)
                    else stringResource(R.string.superdevice_untrusted)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        d.trustedDevice?.let { vm.pairingManager.connectTo(it) }
                        confirm = null
                    },
                    enabled = d.trustedDevice != null,
                ) { Text(stringResource(R.string.connect)) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}
